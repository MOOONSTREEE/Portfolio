#Noé Coëffic | Enis Celikovic
#Script Trieur

#TRIEUR



import os
import json
from pathlib import Path

# Fonction 1 : Construire la liste des fichiers
def construire_liste_fichiers(repertoire_de_base):
    liste_fichiers = []
    # Utilisation de Path pour parcourir récursivement tous les fichiers
    for chemin_fichier in Path(repertoire_de_base).rglob('*'):
        if chemin_fichier.is_file():
            # Ajouter le chemin complet et la taille du fichier
            liste_fichiers.append([str(chemin_fichier), chemin_fichier.stat().st_size])
    return liste_fichiers

# Fonction 2 : Trier la liste des fichiers par taille
def trier_liste_par_taille(liste_fichiers):
    liste_fichiers_triee = sorted(liste_fichiers, key=lambda x: x[1], reverse=True)
    return liste_fichiers_triee

# Fonction 3 : Filtrer la liste des fichiers selon la taille minimale et le nombre maximal
def filtrer_liste_fichiers(liste_fichiers, taille_min_fichier_en_mo, nb_max_fichiers):
    taille_min_en_octets = taille_min_fichier_en_mo * 1048576  # Convertir Mo en octets
    liste_fichiers_filtree = [
        fichier for fichier in liste_fichiers 
        if fichier[1] > taille_min_en_octets
    ]
    # Limiter à un nombre maximal de fichiers
    return liste_fichiers_filtree[:nb_max_fichiers]

# Fonction 4 : Sauvegarder la liste des fichiers dans un fichier JSON
def sauvegarder_liste_en_json(liste_fichiers, nom_fichier_json):
    # Sauvegarder la liste dans un fichier JSON
    with open(nom_fichier_json, 'w', encoding='utf-8') as f:
        json.dump(liste_fichiers, f, indent=4)

# Fonction principale pour exécuter les étapes
def main():
    # Étape 1 : Définir le répertoire de base (automatique)
    # Utilisation de Path() pour gérer les chemins en fonction du système d'exploitation
    repertoire_de_base = Path('C:/MachinesVirtuelles/Masters')  # Utilisez des barres obliques ou des doubles antislashs

    # Étape 2 : Construire la liste des fichiers
    liste_fichiers = construire_liste_fichiers(repertoire_de_base)

    # Étape 3 : Trier la liste par taille
    liste_fichiers_triee = trier_liste_par_taille(liste_fichiers)

    # Étape 4 : Filtrer les fichiers selon la taille minimale et le nombre maximal
    taille_min_fichier_en_mo = 10  # Par exemple, fichiers de plus de 10 Mo
    nb_max_fichiers = 50  # Limiter à 50 fichiers
    liste_fichiers_filtree = filtrer_liste_fichiers(liste_fichiers_triee, taille_min_fichier_en_mo, nb_max_fichiers)

    # Étape 5 : Sauvegarder la liste des fichiers dans un fichier JSON
    nom_fichier_json = 'fichiers_triees.json'
    sauvegarder_liste_en_json(liste_fichiers_filtree, nom_fichier_json)

    # Optionnel : Affichage des fichiers filtrés et sauvegardés
    print(f"Liste des fichiers filtrés et sauvegardés dans {nom_fichier_json} :")
    for fichier in liste_fichiers_filtree:
        print(f"{fichier[0]} - Taille : {fichier[1]} octets")

# Exécution du programme principal uniquement si ce fichier est exécuté directement
if __name__ == "__main__":
    main()

# Script PowerShell pour exécuter l'analyse des gros fichiers et générer un script de suppression

# 1️⃣ Sélection du répertoire avec le premier script Python
$rep_base = python Script-Trieur.py | Out-String
$rep_base = $rep_base.Trim()

if (-not $rep_base) {
    Write-Output "Aucun répertoire sélectionné. Fin du script."
    exit
}

Write-Output "Répertoire sélectionné : $rep_base"

# 2️⃣ Analyse du répertoire et génération du fichier JSON
python Script-Selecteur.py "$rep_base"

if (-not (Test-Path "resultats.json")) {
    Write-Output "Erreur : Le fichier resultats.json n'a pas été créé. Fin du script."
    exit
}

Write-Output "Analyse terminée. Résultats enregistrés dans resultats.json."

# 3️⃣ Affichage des résultats sous forme de camembert
python Script-Graph.py

Write-Output "Affichage du camembert terminé."

# Génération du script PowerShell de suppression des fichiers sélectionnés
$script_suppression = "script_suppression.ps1"

Write-Output "Génération du script de suppression..."
$contenu_script = @'
Write-Output "Script PowerShell pour supprimer les fichiers sélectionnés"
Write-Output "Attention : cette suppression est définitive !"

$reponse = Read-Host "Confirmez la suppression (OUI)"
if ($reponse -eq "OUI") {
    $confirmation = Read-Host "Êtes-vous sûr(e) ? (OUI)"
    if ($confirmation -eq "OUI") {
'@

# Lecture du fichier JSON pour extraire les fichiers sélectionnés
$fichiers = Get-Content "resultats.json" | ConvertFrom-Json
foreach ($fichier in $fichiers) {
    $chemin_complet = $fichier[0]
    # Utilisation de guillemets doubles échappés
    $contenu_script += "    Remove-Item -Path `"$chemin_complet`" -Force`n"
}

$contenu_script += @'
    } else {
        Write-Output "Opération annulée."
    }
} else {
    Write-Output "Opération annulée."
}
'@

$contenu_script | Set-Content $script_suppression
Write-Output "Script de suppression généré : $script_suppression"

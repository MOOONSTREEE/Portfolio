Outil d'analyse des gros fichiers — SAE1.05 (BUT R&T, IUT de Colmar)
Auteurs : Noé Coëffic, Enis Celikovic

Pipeline (Python 3 + PyQt5 / PyQtChart) :
  1. Script-Selecteur.py  — sélection du répertoire à analyser (boîte de dialogue)
  2. Script-Trieur.py     — parcours récursif, tri par taille, filtrage, export JSON
  3. Script-Graph.py      — IHM : camembert de répartition + sélection des fichiers
                            puis génération d'un script PowerShell de suppression
  -> supprime_fichiers.ps1 / Script-Powershell.ps1 : suppression confirmée des fichiers

Dépendances : pip install PyQt5 PyQtChart

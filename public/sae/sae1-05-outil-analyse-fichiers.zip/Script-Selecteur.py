#Noé Coëffic | Enis Celikovic
#Script Selecteur

import sys
from PyQt5.QtWidgets import QApplication, QFileDialog, QWidget
from pathlib import Path

# Fonction pour ouvrir un sélecteur de répertoire et retourner le chemin sélectionné
def selectionner_repertoire():
    app = QApplication(sys.argv)  # Créer l'application PyQt

    # Ouvrir la boîte de dialogue de sélection de répertoire
    dialog = QFileDialog()
    dialog.setFileMode(QFileDialog.Directory)  # Limiter la sélection aux répertoires
    dialog.setOption(QFileDialog.ShowDirsOnly, True)  # Afficher uniquement les répertoires
    
    # Exécuter la boîte de dialogue et obtenir le répertoire sélectionné
    if dialog.exec_():
        repertoire_selectionne = dialog.selectedFiles()[0]
        print(f"Répertoire sélectionné : {repertoire_selectionne}")
        
        # Utilisation de pathlib pour rendre le chemin compatible multiplateforme
        repertoire_path = Path(repertoire_selectionne)
        return repertoire_path
    else:
        print("Aucun répertoire sélectionné.")
        return None

# Fonction principale
def main():
    repertoire = selectionner_repertoire()
    
    if repertoire:
        print(f"Répertoire retourné par la fonction : {repertoire}")
    else:
        print("Aucun répertoire n'a été sélectionné.")

if __name__ == "__main__":
    main()
